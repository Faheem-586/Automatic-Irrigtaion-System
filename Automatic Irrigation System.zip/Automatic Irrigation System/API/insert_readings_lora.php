<?php
include 'db.php';


$host 		= "";
$user       = "";
$password 	= "";
$database 	= "";
$db = new db($host, $user, $password, $database);

 
$D = $_GET['D'];
$H = $_GET['H'];
$T = $_GET['T'];
$M = $_GET['M'];
 



    if($D=='on')
    { 
    date_default_timezone_set('Asia/Karachi');
    $current_date_time = date("Y-m-d h:i:s");
    $current_time = date("h:i:s");
                                                       
        $insert = $db->query('INSERT INTO irrigation_processes (duration,start_time,date) VALUES (?,?,?)',0,$current_time,$current_date_time);
        echo $insert->affectedRows();
         
    }
    else  if($D=='off')
    {
        $lastdata = $db->query('SELECT * FROM irrigation_processes order by irrigation_ID desc limit 1')->fetchArray();
 
        date_default_timezone_set('Asia/Karachi');
       
        $current_time_2 = date("h:i:s");

     	$sql="update irrigation_processes set end_time='$current_time_2', duration=TIMEDIFF('$current_time_2', '".$lastdata ['start_time']."'), rounded_duration = time_to_sec(TIMEDIFF('$current_time_2', '".$lastdata ['start_time']."'))/60  where irrigation_ID='".$lastdata['irrigation_ID']."'";
     echo $sql;
        $insert = $db->query($sql);
        echo $insert->affectedRows();
    }

else
{ 
       date_default_timezone_set('Asia/Karachi');
       $current_date = date("Y-m-d h:i:s");
       //$newDate = new DateTime(date('m/d/Y h:i:s a', time()));
       //$current_date = $newDate->format('d-m-Y h:i:s');

$insert = $db->query('INSERT INTO sensor_values (temperature,humidity,moisture,date_and_time) VALUES (?,?,?,?)',$T,$H,$M,$current_date);
echo $insert->affectedRows();
}

?>