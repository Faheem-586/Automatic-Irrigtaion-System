<?php
session_start();

if (!isset($_SESSION["login_email"])) {
    header("location: signup.php");
    exit;
}
?>

<!doctype html>
<html class="no-js" lang="">


<head>

    <?php include_once('links.php') ?>

    <title>Automatic Irrigation System</title>

    <style>
        .left-panel {
            max-width: 200px;
        }

        .right-panel {
            margin-left: 200px;
        }
    </style>
</head>

<body>
    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php"><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                    </li>

                    <li class="active">
                        <a href="table_IR.php"><i class="menu-icon fa fa-table"></i>Statistics </a>
                    </li>

                    <li>
                        <a href="graph_irrigation.php"><i class="menu-icon fa fa-industry"></i>Graphs </a>
                    </li>

                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>
    <!-- /#left-panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">


        <?php include_once('header.php') ?>

        <!-- Content -->
        <div class="content">

            <!-- Animated -->
            <div class="animated fadeIn">
                <!-- Widgets  -->
                <div class="row">

                    <ul class="nav nav-pills mb-3">
                        <li class="nav-item">
                            <a class="nav-link active" href="table_IR.php" role="tab">Irrigation Records</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="table_SN.php" role="tab">Sensor Reading</a>
                        </li>

                    </ul>

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <ul class="nav nav-pills mb-3">
                                    <li class="nav-item">
                                        <a class="nav-link  active" href="table_IR.php" role="tab">All Records</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="table_IR_daily.php" role="tab">Daily Average</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="table_IR_monthly.php" role="tab">Monthly Average</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="table_IR_yearly.php" role="tab">Yearly Average</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Irrigation ID</th>
                                            <th>Duration</th>
                                            <th>Start Time</th>
                                            <th>End Time</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        include_once("DBConnection.php");
                                        date_default_timezone_set("Asia/Karachi");
                                        $conn = new DBCon();

                                        if ($conn->Open()) {
                                            $sql = " SELECT * FROM irrigation_processes";
                                            $result = $conn->db->query($sql);

                                            if ($result->num_rows > 0) {
                                                while ($row = $result->fetch_assoc()) {

                                                    $newDate = new DateTime($row['date']);
                                                    $date = $newDate->format('Y-m-j');

                                                    $newDate = new DateTime($row['start_time']);
                                                    $start_time = $newDate->format('g:i a');

                                                    $newDate = new DateTime($row['end_time']);
                                                    $end_time = $newDate->format('g:i a');
                                                    
                                                    
                                                    $newDate = new DateTime($row['duration']);
		//$hr= $newDate->format('H');
      		$min= $newDate->format('i');
      		$min= (int)$min;
      		
   		$sec= $newDate->format('s');
   		$sec= (int)$sec;
   		
                                        ?>

                                                    <tr>
                                                        <td><?php echo $row['irrigation_ID']; ?></td>
                                                        <td><?php echo $min.' min, &nbsp;&nbsp;'.$sec.' sec';  ?></td>
                                                        <td><?php echo $start_time; ?></td>
                                                        <td><?php echo $end_time; ?></td>
                                                        <td><?php echo $date; ?></td>
                                                    </tr>

                                        <?php

                                                }
                                            }
                                            $conn = null;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>


            </div>
            <!-- .animated -->
        </div>

        <!-- /.content -->
        <div class="clearfix"></div>
        <!-- Footer -->
        <br><br><br><br><br><br><br><br><br><br><br><br>
        <?php include_once('footer.php') ?>

        <!-- /.site-footer -->
    </div>
    <!-- /#right-panel -->
</body>
<?php include_once('scripts.php') ?>
<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="assets/js/main.js"></script>

<script src="assets/js/lib/data-table/datatables.min.js"></script>
<script src="assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
<script src="assets/js/lib/data-table/dataTables.buttons.min.js"></script>
<script src="assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
<script src="assets/js/lib/data-table/jszip.min.js"></script>
<script src="assets/js/lib/data-table/vfs_fonts.js"></script>
<script src="assets/js/lib/data-table/buttons.html5.min.js"></script>
<script src="assets/js/lib/data-table/buttons.print.min.js"></script>
<script src="assets/js/lib/data-table/buttons.colVis.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#bootstrap-data-table').DataTable({
            "order": [
                [0, "desc"]
            ]
        });
    });
</script>



</html>