<?php
session_start(); 
?>
 
<!doctype html>
<html class="no-js" lang="">

<head>
  <?php include_once('links.php') ?>

  <title>Automatic Irrigtaion System</title>


  <style>
    .site_title {
      color: white;
      padding-bottom: 45px;
      text-align: center;
    }

    .Error_msg {
      font-size: 14px;
      color: red;
      text-align: center;
      font-weight: bold;
    }

    .Success_msg {
      font-size: 14px;
      color: rgb(0, 75, 31);
      text-align: center;
      font-weight: bold;
    }
  </style>


</head>

<body class="bg-dark">

  <div class="sufee-login d-flex align-content-center flex-wrap">
    <div class="container">
      <div class="login-content">
        <h1 class="site_title">Automatic Irrigtaion System</h1>
        <div class="login-form">
          <form role="form" method="POST">
            <div class="form-group">
              <label>Email address</label>
              <input type="email" name="EMAIL" class="form-control" placeholder="Email" required>
            </div>
            <div class="form-group">
              <label>Password</label>
              <input type="password" name="PASSWORD" class="form-control" placeholder="Password" required>
            </div>

            <br>
            <button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30">Sign in</button>
            <br>
            

            
            <br>
            
<?php 
if (isset($_POST["EMAIL"])) {


  include_once("DBConnection.php");
  date_default_timezone_set("Asia/Karachi");
  $conn = new DBCon();

  $email = $_POST['EMAIL'];
  $pwd = $_POST['PASSWORD'];
 
 
if ($conn->Open()) {
    $sql = "select * from users where userid='$email' and password='$pwd'";


    $result = $conn->db->query($sql);

    $row = $result->fetch_assoc();

    $usrname = $row['name'];
    $usremail = $row['userid'];

    if ($result->num_rows > 0) { 
      $_SESSION['login_user'] = $usrname;
      $_SESSION['login_email'] = $usremail;
 
      header('Location:index.php');

    } else {
      echo  "<p class='Error_msg'> ✖ Invalid Username or Password.. </p>";
    }


    $conn = null;
  }
}
?>

<br>
            <div class="register-link m-t-15 text-center">
              <p>Don't have account ? <a href="signup.php"> Sign Up Here</a></p>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
  <script src="assets/js/main.js"></script>

</body>

</html>