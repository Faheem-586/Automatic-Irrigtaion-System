<?php
session_start();

if (!isset($_SESSION["login_email"])) {
    header("location: signup.php");
    exit;
}
?>

<!doctype html>
<html class="no-js" lang="">


<head>

    <?php include_once('links.php') ?>

    <title>Automatic Irrigation System</title>
    <style>
        .left-panel {
            max-width: 200px;
        }

        .right-panel {
            margin-left: 200px;
        }

        .card-text {
            font-family: corbel;
            color: black;
            font-size: 22px;
        }

        .card-text-big {
            font-family: calibri;
            color: white;
            font-weight: bold;
            font-size: 42px;
            float: right;
        }

        .card-text-sm {
            font-family: calibri;
            color: black;
            font-weight: bold;
            font-size: 16px;
        }

        .card-text-unit {
            font-family: calibri;

            font-size: 24px;
        }
    </style>

</head>

<body>
    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.php"><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                    </li>

                    <li>
                        <a href="table_IR.php"><i class="menu-icon fa fa-table"></i>Statistics </a>
                    </li>

                    <li>
                        <a href="graph_irrigation.php"><i class="menu-icon fa fa-industry"></i>Graphs </a>
                    </li>
 
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>
    <!-- /#left-panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">

        <?php include_once('header.php') ?>

       <?php
                    include_once("DBConnection.php");
                    date_default_timezone_set("Asia/Karachi");
                    $conn = new DBCon();

                    if ($conn->Open()) {

                        $sql = "SELECT * FROM irrigation_processes order by irrigation_ID desc limit 1";
                        $result = $conn->db->query($sql);
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $end_time = $row['end_time'];
                            if ($end_time == NULL) {
                                $valve_status = 'ON';
                            } else {
                                $valve_status = 'OFF';
                            }
                        }

                    ?>
       

                <!-- Content -->
                <div class="content">

                    <!-- Animated -->
                    <div class="animated fadeIn">
                        <!-- Widgets  -->

                        <div class="row"> 
                        <div class="col-sm-6 col-lg-3">
                            <div style="background-color:#B29BC7" class="card text-white">
                                <div class="card-body">

                                    <small class="card-text-sm">Current</small>
                                    <p class="card-text"> <b>Valve Status</b>

                                        <span class="card-text-big"> <?php echo $valve_status ?><small class="card-text-unit"> </small></span>
                                    </p>
                                </div>
                            </div>
                        </div>


                    <?php

                $conn = null;
            }
                    ?>

                    <?php
                    include_once("DBConnection.php");
                    date_default_timezone_set("Asia/Karachi");
                    $conn = new DBCon();

                    if ($conn->Open()) {
                        $sql = "SELECT * FROM sensor_values ORDER BY date_and_time DESC";
                        $result = $conn->db->query($sql);

                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc()

                    ?>

                            <div class="col-sm-6 col-lg-3">

                                <div style="background-color:#B29BC7" class="card text-white">
                                    <div class="card-body">
                                        <small class="card-text-sm">Current</small>
                                        <p class="card-text"> <b>Temperature</b>
                                            &nbsp;&nbsp;
                                            <span class="card-text-big"> <?php echo $row['temperature']; ?><small class="card-text-unit">°C</small></span>
                                        </p>

                                    </div>
                                </div>
                            </div>
                            <!--/.col-->


                            <div class="col-sm-6 col-lg-3">


                                <div style="background-color:#B29BC7" class="card text-white">
                                    <div class="card-body">

                                        <small class="card-text-sm">Current</small>
                                        <p class="card-text"> <b>Humidity</b>
                                            &nbsp;&nbsp;
                                            <span class="card-text-big"> <?php echo $row['humidity']; ?><small class="card-text-unit">g/c³</small></span>
                                        </p>

                                    </div>


                                </div>



                            </div>
                            <!--/.col-->

                            <div class="col-sm-6 col-lg-3">
                                <div style="background-color:#B29BC7" class="card text-white">
                                    <div class="card-body">

                                        <small class="card-text-sm">Current</small>
                                        <p class="card-text"> <b>Soil Moisture</b>
                                            &nbsp;&nbsp;
                                            <span class="card-text-big"> <?php echo $row['moisture']; ?><small class="card-text-unit">m³</small></span>
                                        </p>
                                    </div>
                                </div>
                            </div>


                    <?php

                        }
                        $conn = null;
                    }
                    ?>



              
                        </div>
                        <!-- /Widgets -->

                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong class="card-title">Recent Irrigation Processes</strong>
                                    </div>
                                    <div class="card-body">
                                        <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Irrigation ID</th>
                                                    <th>Duration</th>
                                                    <th>Start Time</th>
                                                    <th>End Time</th>
                                                    <th>Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                include_once("DBConnection.php");
                                                date_default_timezone_set("Asia/Karachi");
                                                $conn = new DBCon();

                                                if ($conn->Open()) {
                                                    $sql = "SELECT * FROM irrigation_processes ORDER BY irrigation_ID DESC limit 7";
                                                    $result = $conn->db->query($sql);

		
      		
                                                    $flag = 0;
                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {

                                                            $date = new DateTime($row['date']);
                                                            $date = $date->format('Y-m-d');

                                                            $start_time = new DateTime($row['start_time']);
                                                            $start_time = $start_time->format('H:i a');

                                                            $end_time = new DateTime($row['end_time']);
                                                            $end_time = $end_time->format('H:i a');


		$newDate = new DateTime($row['duration']);
		//$hr= $newDate->format('H');
      		$min= $newDate->format('i');
      		$min= (int)$min;
      		
   		$sec= $newDate->format('s');
   		$sec= (int)$sec;
                                                ?>
                                                            <tr>
                                                                <td><?php echo $row['irrigation_ID']; ?></td>
                                                                <td><?php echo $min.' min, &nbsp;&nbsp;'.$sec.' sec'; ?></td>
                                                                <td><?php echo $start_time; ?></td>
                                                                <td><?php echo $end_time; ?></td>
                                                                <td><?php echo $date; ?></td>
                                                            </tr>

                                                <?php
                                                            $flag++;
                                                            //     echo $flag;
                                                        }
                                                    }
                                                    $conn = null;
                                                }
                                                ?>


                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>
                    <!-- .animated -->
                </div>

                <!-- /.content -->
                <div class="clearfix"></div>
                <!-- Footer -->
                <br><br><br><br><br><br><br><br><br><br><br><br>
                <?php include_once('footer.php') ?>

 
                <!-- /.site-footer -->
    </div>
    <!-- /#right-panel -->
</body>
<?php include_once('scripts.php') ?>
<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="assets/js/main.js"></script>

<script src="assets/js/lib/data-table/dataTables.buttons.min.js"></script>
<script src="assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
<script src="assets/js/lib/data-table/jszip.min.js"></script>
<script src="assets/js/lib/data-table/vfs_fonts.js"></script>
<script src="assets/js/lib/data-table/buttons.html5.min.js"></script>
<script src="assets/js/lib/data-table/buttons.print.min.js"></script>
<script src="assets/js/lib/data-table/buttons.colVis.min.js"></script>
<script src="assets/js/init/datatables-init.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $('#bootstrap-data-table-export').DataTable();
    });
</script>



</html>