

<footer style="margin-top:15%" class="site-footer">
    <div style="background-color:#CDD4D7;  border-top: 2px solid black;" class="footer-inner">
        <div class="row">
            <div style="color:black" class="col-sm-6">
                Copyright &copy; 2020 <a class="basic-link" href="index.php"> Automatic Irrigation System </a>
            </div>
            <div class="col-sm-6 text-right">
                  Designed by <a href="https://web.facebook.com/mohammad.faheem.56863221">Muhammad Faheem</a> 
            </div>
        </div>
    </div>
</footer>

 