<!doctype html>
<html class="no-js" lang="">

<head>
  <?php include_once('links.php') ?>

  <title>Automatic Irrigtaion System</title>


  <style>
    .site_title {
      color: white;
      padding-bottom: 45px;
      text-align: center;
    }

    .Error_msg {
      font-size: 14px;
      color: rgb(75, 0, 0);
      text-align: center;
      font-weight: bold;
    }

    .Success_msg {
      font-size: 14px;
      color: rgb(0, 75, 31);
      text-align: center;
      font-weight: bold;
    }
  </style>


</head>

<body class="bg-dark">

  <div class="sufee-login d-flex align-content-center flex-wrap">
    <div class="container">
      <div class="login-content">
        <h1 class="site_title">Automatic Irrigtaion System</h1>
        <div class="login-form">
          <div class="login-form">

          
            <form role="form" method="POST">
              <div class="form-group">
                <label>User Name</label>
                <input type="text" name="USERNAME" class="form-control" placeholder="User Name" required>
              </div>
              <div class="form-group">
                <label>Email address</label>
                <input type="email" name="EMAIL" class="form-control" placeholder="Email Address" required>
              </div>
              <div class="form-group">
                <label>Password</label>
                <input type="password" name="PASSWORD" class="form-control" placeholder="Password" required>
              </div>

              <button type="submit" class="btn btn-primary btn-flat m-b-30 m-t-30">Register</button>
              <br>
              <br>

              <?php
              if (isset($_POST["USERNAME"])) {


                include_once("DBConnection.php");
                date_default_timezone_set("Asia/Karachi");
                $conn = new DBCon();

                $conn->open();
                $usrname = $_POST['USERNAME'];
                $email = $_POST['EMAIL'];
                $pswrd = $_POST['PASSWORD'];

                //   echo $usrname;
                $sql = null;

                $sql = "INSERT INTO users (userid, name, password) VALUES ('$email', '$usrname','$pswrd')";
                //    echo $sql;
                if ($conn->db->query($sql) ==  TRUE) {
                  echo "  
                 <span class='pull-left'><h6 class='Success_msg'> ✓ Thank You...! </h6></span>
                 <span class='pull-right'><h6 class='Success_msg'><a href='login.php'>Now Login here..!</a></h6></span>
               <br><br>";
                } else {
                  echo "<h5 class='Error_msg'> ✖ Already have an account on this email...!</h5><br>";
                }
                $conn->db->close();
              }
              ?>
            </form>


            <div class="register-link m-t-15 text-center">
              <p>Already have account ? <a href="login.php"> Sign in</a></p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="assets/js/main.js"></script>

</body>