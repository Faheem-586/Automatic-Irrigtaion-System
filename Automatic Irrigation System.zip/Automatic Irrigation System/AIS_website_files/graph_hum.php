<?php
session_start();  

if (!isset($_SESSION["login_email"])) {
    header("location: signup.php");
    exit;  
}
?>
<!doctype html>
<html class="no-js" lang="">


<head>

    <?php include_once('links.php') ?>

    <title>Automatic Irrigation System</title>

    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <style>
        .graph_title {
            color: #007BFF;
            padding-bottom: 15px;
            text-align: center;
        }

        .graph_container {
            width: 1250px;
            height: 500px;

        }

        .card {
            margin-left: 15px;
        }

        .left-panel {
            max-width: 200px;
        }

        .right-panel {
            margin-left: 200px;
        }
    </style>


</head>

<body>
    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php"><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                    </li>

                    <li>
                        <a href="table_IR.php"><i class="menu-icon fa fa-table"></i>Statistics </a>
                    </li>

                    <li class="active">
                        <a href="graphs.php"><i class="menu-icon fa fa-industry"></i>Graphs </a>
                    </li>

                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>
    <!-- /#left-panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">


        <?php include_once('header.php') ?>

        <!-- Content -->
        <div class="content">

            <!-- Animated -->
            <div class="animated fadeIn">
                <!-- Widgets  -->
                <div class="row">

                    <!-- Graph Navbar Panel -->
                    <ul class="nav nav-pills mb-3">
                        <li class="nav-item">
                            <a class="nav-link" href="graph_irrigation.php" role="tab">Irrigation Graph</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="graph_temp.php" role="tab">Temperature Graph</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="graph_hum.php" role="tab">Humidity Graph</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="graph_moisture.php" role="tab">Moisture Graph</a>
                        </li>
                    </ul>


                    <div class="card">
                        <div id="hum_graph" class="graph_container"></div>
                        <h4 class="graph_title">GRAPH: &nbsp;&nbsp;&nbsp; Average Humidity</h4>
                    </div>

                </div>


            </div>
            <!-- .animated -->
        </div>

        <!-- /.content -->
        <div class="clearfix"></div>
        <!-- Footer -->
        <br><br><br><br><br><br><br><br><br><br><br><br>
        <?php include_once('footer.php') ?>


        <!-- /.site-footer -->
    </div>
    <!-- /#right-panel -->
</body>
<?php include_once('scripts.php') ?>
<!-- Scripts -->
<script type="text/javascript">
    google.charts.load('current', {

        'packages': ['corechart'],

        'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'

    });

    google.charts.setOnLoadCallback(drawRegionsMap);


    function drawRegionsMap() {

        var data = google.visualization.arrayToDataTable([

            ['date', 'humidity'],

            <?php
            include_once("DBConnection.php");
            date_default_timezone_set("Asia/Karachi");
            $conn = new DBCon();

            if ($conn->Open()) {

                $sql = "SELECT AVG(humidity) as avg_hum, DATE_FORMAT(date_and_time, '%Y-%m-%d') as mydate FROM  sensor_values group by DATE_FORMAT(date_and_time, '%Y-%m-%d')";
                $result = $conn->db->query($sql);

                while ($row = mysqli_fetch_assoc($result)) {

                    echo "['" . $row['mydate'] . "',"  . $row['avg_hum'] . "],";
                }
                $conn = null;
            }
            ?>

        ]);


        var options = {

        };


        var chart = new google.visualization.LineChart(document.getElementById('hum_graph'));


        chart.draw(data, options);

    }
</script>

<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="assets/js/main.js"></script>


<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>


</html>