  <!-- Header-->
  <header id="header" class="header">
      <div class="top-left">
          <div class="navbar-header">
              <span class='site_logo'>Automatic Irrigation System</span>
              <a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
              <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
          </div>
      </div>
      <div class="top-right">
          <div class="header-menu">
              <div style="padding-right:30px" class="header-left">

                  <div style="padding-right:30px" class="user-area dropdown float-right">

                      <?php if (isset($_SESSION['login_user']))
                            echo '<a href="logout.php" class="active"> <i class="fa fa-sign-out"></i> Sign out </a>';
                        else   echo '<a href="login.php" class="active"> <i class="fa fa-sign-in"></i> Log In</a>' ?>

                  </div>

                  <div style="padding-right:30px;" class="user-area dropdown float-right">
                      <?php if (isset($_SESSION['login_user']))
                            echo " <i class='fa fa-user'> </i> <span  style='font-family:calibri; font-size:18px'> User: " . $_SESSION['login_user'] . "</span>";
                        else   echo "<a href='signup.php'  class='active'><i class='fa fa-edit'></i> Register</a>"  ?>
                  </div>




              </div>
          </div>
  </header>
  <!-- /#header -->