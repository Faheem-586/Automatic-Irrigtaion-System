  <!-- Footer -->
  <footer class="footer ptb-20">
      <div class="row">
          <div class="col-12 text-center">
              <div class="copy_right">
                  <p>
                      <span style="color:#a6a7a8">© Automatic Irrigation System</span>   &nbsp;&nbsp;&nbsp;
                      <a style="color:grey" href="index.php" class="btn  btn-outline-secondary"><i class="icon-home "></i> Home</a>
                  </p>
              </div>

          </div>
      </div>
  </footer>
  <!-- Footer_End -->