<div class="side_bar scroll_auto">
    <ul id="dc_accordion" class="sidebar-menu tree">

        <li class="menu_sub">
            <hr>
        </li>

        <li class="menu_title">
            <a href="index.php"> <i class="fa fa-home"></i> Home </a>
        </li>

        <li class="menu_sub">
            <hr>
        </li>

        <li class="menu_title">
            <a href="statistics.php"><i class="fa fa-bar-chart"></i> Statistics</a>
        </li>

        <li class="menu_sub">
            <hr>
        </li>


        <li class="menu_title">
            <a href="modules.php"><i class="fa fa-bar-chart"></i> Modules</a>
        </li>

        <li class="menu_sub">
            <hr>
        </li>

        <br><br> 
        <!--
        <li class="menu_sub">
            <hr>
        </li>

        <li class="menu_title">
            <a href="page_404.php"><i class="fa fa-pie-chart"></i> Graphs</a>
        </li>
-->

 

        <li class="menu_sub">

            <a> <b> User: </b><br> <?php if (isset($_SESSION['login_user'])) echo $_SESSION['login_user'];
                                    else echo "No user signed in..!"; ?></a>


        </li>
        <li class="menu_sub">
            <hr>
        </li>
        <li class="menu_title">

            <?php if (isset($_SESSION['login_user']))
                echo '<a href="logout.php"><i class="fa fa-sign-out"></i>Sign out</a>';
            else   echo '<a href="login.php"><i class="fa fa-sign-in"></i>Sign In</a>';
            ?>
        </li>


        <li class="menu_sub">
            <hr>
        </li>


     

</div>