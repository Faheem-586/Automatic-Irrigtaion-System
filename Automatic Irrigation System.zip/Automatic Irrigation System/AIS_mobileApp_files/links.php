<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">


<link rel="shortcut icon" type="image/x-icon" href="favicon.ico">


<!-- google font -->
<link href="assets/css/googleapis_poppins" rel="stylesheet" type="text/css" />
<link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="assets/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="assets/css/ionicons.css" rel="stylesheet" type="text/css">
<link href="assets/css/simple-line-icons.css" rel="stylesheet" type="text/css">
<link href="assets/css/jquery.mCustomScrollbar.css" rel="stylesheet">
<link href="assets/css/weather-icons.min.css" rel="stylesheet">


<!--Morris Chart -->
<link rel="stylesheet" href="assets/js/index/morris-chart/morris.css">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/fstyle.css" rel="stylesheet">
<link href="assets/css/responsive.css" rel="stylesheet">