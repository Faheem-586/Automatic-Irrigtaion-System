  <!-- header -->
  <header class="main-header">
      <div class="container_header">
          <div class="d-flex align-items-center">

              <div class="icon_menu full_menu">
                  <a href="#!" class="menu-toggler sidebar-toggler"></a>
              </div>


          </div>
          <div class="Site_title">
              Automatic Irrigation System
          </div>
      </div>

  </header>
  <!-- header_End -->