<?php
session_start();

if (!isset($_SESSION["login_email"])) {
    header("location: signup.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <?php include_once('links.php') ?>

    <title>Automatic Irrigation System</title>

</head>

<body>
    <div id="loader_wrpper">
        <div class="loader_style"></div>
    </div>

    <div class="wrapper">
        <?php include_once('header.php') ?>

        <!-- Content_right -->
        <div class="container_full">

            <?php include_once('menu.php') ?>

            <div class="content_wrapper">
                <div class="container-fluid">
                    <!-- breadcrumb -->
                    <div>
                        <br>
                    </div>
                    <!-- Section -->
                    <section class="chart_section">

                        <br><br><br>

                        <div class="row">

                            <div class="col-3">
                            </div>

                            <div class="col-6">
                                <a href="table_SN.php" class="btn btn-outline-dark btn-lg  btn-block"> <b>Show <br> Sensor<br> Readings</b></a>
                            </div>

                            <div class="col-3">
                            </div>
 
                        </div>

                        <br><br><br>

                        <div class="row">

                            <div class="col-3">
                            </div>

                            <div class="col-6">
                                <a href="table_IR.php" class="btn btn-outline-dark btn-lg  btn-block"><b> Show <br> Irrigation<br> Records</b></a>

                            </div>

                            <div class="col-3">
                            </div>
 
                        </div>

                        <br><br><br>
                        
                        
                        <div class="row">

                            <div class="col-3">
                            </div>

                            <div class="col-6">
                                <a href="index.php" class="btn btn-outline-dark btn-lg  btn-block"><b> Back <br> to<br> Home</b></a>

                            </div>

                            <div class="col-3">
                            </div>
 
                        </div>

                    </section>
                    <!-- Section_End -->

                </div>
            </div>
        </div>
        <!-- Content_right_End -->
        <!-- Footer -->
        <?php include_once('footer.php') ?>
        <!-- Footer_End -->
    </div>

    <?php include_once('scripts.php') ?>

</body>

</html>