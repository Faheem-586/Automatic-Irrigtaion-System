<?php
session_start();

if (!isset($_SESSION["login_email"])) {
    header("location: signup.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <?php include_once('links.php') ?>

    <title>Automatic Irrigation System</title>

</head>

<body>
    <div id="loader_wrpper">
        <div class="loader_style"></div>
    </div>

    <div class="wrapper">
        <?php include_once('header.php') ?>


        <?php
        include_once("DBConnection.php");
        date_default_timezone_set("Asia/Karachi");
        $conn = new DBCon();

        if ($conn->Open()) {
            $sql = "SELECT * FROM irrigation_processes ORDER BY irrigation_ID DESC";
            $result = $conn->db->query($sql);


            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();

                $newDate = new DateTime($row['date']);
                $date = $newDate->format('j - m - Y');

                $newDate = new DateTime($row['start_time']);
                $time = $newDate->format('H:i a');

        ?>


                <!-- Content_right -->
                <div class="container_full">

                    <?php include_once('menu.php') ?>

                    <div class="content_wrapper">
                        <div class="container-fluid">
                            <!-- breadcrumb -->
                            <div>
                                <h6></h6>
                            </div>
                            <!-- Section -->
                            <section class="chart_section">

                                <div class="row">
                                    <div class="col-12">
                                        <div   style="background-color:#2ED8B6" class="info_items d-flex align-items-center">

                                            <div class="info_item_content">
                                                <span style="color:black; font-family:calibri; font-size:15px; font-weight:bold;">Recent Irrigation</span><br> 
                                                    <span style="color:black; font-family:calibri; font-size:24px; font-weight:bold;"><?php echo $time.'<br>' ?></span>
                                                    <span style="color:black; font-family:calibri; font-size:18px; "><?php echo $date; ?></span>
                                               
                                            </div>

                                            <div class="info_item_content">
                                                <span class="card-text-big"> <?php echo $row['duration']; ?><small class="card-text-unit">min</small>&nbsp; </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                        <?php

                    }
                    $conn = null;
                }
                        ?>

                        <?php
                        include_once("DBConnection.php");
                        date_default_timezone_set("Asia/Karachi");
                        $conn = new DBCon();

                        if ($conn->Open()) {
                            $sql = "SELECT * FROM sensor_values ORDER BY date_and_time DESC";
                            $result = $conn->db->query($sql);


                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc()


                        ?>
                      
                                <div class="row">
                                    <div class="col-12">
                                        <div style="background-color:#2ED8B6" class="info_items d-flex align-items-center">

                                            <div class="info_item_content">
                                                <span class="card-text-sm">Current<br>
                                                    <span class="card-text">Temperature</span>
                                                </span>
                                            </div>

                                            <div class="info_item_content">
                                                <span class="card-text-big"> <?php echo $row['temperature']; ?><small class="card-text-unit">°C </small>&nbsp;</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-12">
                                        <div style="background-color:#2ED8B6" class="info_items  d-flex align-items-center">

                                            <div class="info_item_content">
                                                <span class="card-text-sm">Current<br>
                                                    <span class="card-text">Humidity</span>
                                                </span>
                                            </div>

                                            <div class="info_item_content">
                                                <span class="card-text-big"> <?php echo $row['humidity']; ?><small class="card-text-unit">g/c³</small>&nbsp;</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-12">
                                        <div style="background-color:#2ED8B6" class="info_items d-flex align-items-center">

                                            <div class="info_item_content">
                                                <span class="card-text-sm">Current<br>
                                                    <span class="card-text">Air Moisture</span>
                                                </span>
                                            </div>

                                            <div class="info_item_content">
                                                <span class="card-text-big"> <?php echo $row['moisture']; ?><small class="card-text-unit">m³</small>&nbsp;</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

 
                                <div class="row">
                                    <div class="col-6">
                                        <a  href="table_SN.php"  class="btn btn-outline-dark btn-lg  btn-block"> <b>Show <br> Sensor<br> Readings</b></a>
                                    </div>
                                 
                                    <div class="col-6">
                                        <a href="table_IR.php"  class="btn btn-outline-dark btn-lg  btn-block"><b> Show <br> Irrigation<br> Records</b></a>
                                    </div>
                                </div>

                                <br>
                        <?php

                            }
                            $conn = null;
                        }
                        ?>
                            </section>
                            <!-- Section_End -->

                        </div>
                    </div>
                </div>
                <!-- Content_right_End -->
                <!-- Footer -->
                <?php include_once('footer.php') ?>
                <!-- Footer_End -->
    </div>

    <?php include_once('scripts.php') ?>

</body>

</html>