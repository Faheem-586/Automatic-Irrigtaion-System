<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>

    <title>Automatic Irrigation System</title>

</head>

<body class="bg_darck">

    <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="Page_title">
                    Automatic Irrigation System
                </div>
                <br>
                <div class="login-form">
                    <form role="form" method="POST">
                        <div class="form-group">
                            <label>Email address</label>
                            <input type="email" name="EMAIL" class="form-control" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="PASSWORD" class="form-control" placeholder="Password" required>
                        </div><br>
                        <button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30">Sign in</button>
                        <br>
                        <br>
                        <?php
                        if (isset($_POST["EMAIL"])) {


                            include_once("DBConnection.php");
                            date_default_timezone_set("Asia/Karachi");
                            $conn = new DBCon();

                            $email = $_POST['EMAIL'];
                            $pwd = $_POST['PASSWORD'];

                            if ($conn->Open()) {
                                $sql = "select * from users where userid='$email' and password='$pwd'";

                                $result = $conn->db->query($sql);

                                $row = $result->fetch_assoc();

                                $usrname = $row['name'];
                                $usremail = $row['userid'];

                                if ($result->num_rows > 0) {

                                    $_SESSION['login_user'] = $usrname;
                                    $_SESSION['login_email'] = $usremail;
                                    header('Location:index.php');
                                } else {
                                    echo "<p class='Error_msg'> ✖ Invalid Username or Password.. </p>";
                                }

                                $conn = null;
                            }
                        }
                        ?>

                        <br>
                        <div class="register-link m-t-15 text-center">
                            <p>Don't have account ?
                                <a href="signup.php"> Sign Up Here</a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php include_once('scripts.php') ?>

</body>

</html>