<?php
session_start();

if (!isset($_SESSION["login_email"])) {
    header("location: signup.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>

    <title>Automatic Irrigation System</title>

    <!--bs4 data table-->
    <link href="assets/css/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body>
    <div id="loader_wrpper">
        <div class="loader_style"></div>
    </div>
    <div class="wrapper">

        <!-- header_start -->

        <?php include_once('header.php') ?>

        <!-- header_End -->
        <!-- Content_right -->
        <div class="container_full">

            <?php include_once('menu.php') ?>


            <!--main contents start-->
            <main class="content_wrapper">
                <!--page title start-->

                <!--page title end-->
                <div class="container-fluid">
                    <!-- state start-->
                    <div class="row">



                        <div class=" col-12">
                            <ul class="nav nav-pills mb-3">
                                <li class="nav-item">
                                    <a class="btn btn-outline-secondary" href="table_SN.php" role="tab">All Readings</a>
                                </li>&nbsp;&nbsp;&nbsp;
                                <li class="nav-item">
                                    <a class="btn btn-secondary" href="table_SN_daily.php" role="tab">Average Readings</a>
                                </li>
                            </ul>
                            <div class="card card-shadow mb-4">
                                <div class="card-header">
                                    <small>
                                        <ul class="nav nav-pills mb-3">
                                            <li class="nav-item">
                                                <a class="btn btn-outline-secondary" href="table_SN_daily.php" role="tab">Daily Avg</a>
                                            </li>&nbsp;
                                            <li class="nav-item">
                                                <a class="btn btn-secondary" href="table_SN_monthly.php" role="tab">Monthly Avg</a>
                                            </li>&nbsp;
                                            <li class="nav-item">
                                                <a class="btn btn-outline-secondary" href="table_SN_yearly.php" role="tab">Yearly Avg</a>
                                            </li>
                                        </ul>
                                    </small>

                                </div>
                                <div class="card-body">
                                    <table id="bs4-table" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Month</th>
                                                <th>Average Temp.</th>
                                                <th>Average Humidity</th>
                                                <th>Average Air Moisture</th>

                                            </tr>
                                        </thead>

                                        <tbody>

                                            <?php
                                            include_once("DBConnection.php");
                                            date_default_timezone_set("Asia/Karachi");
                                            $conn = new DBCon();

                                            if ($conn->Open()) {
                                                $sql = "SELECT CEIL(AVG(temperature)) as avg_tem, CEIL(AVG(humidity)) as avg_hum, CEIL(AVG(moisture)) as avg_mos, DATE_FORMAT(date_and_time, '%Y-%m') as month FROM  sensor_values group by DATE_FORMAT(date_and_time, '%Y-%m')";
                                                $result = $conn->db->query($sql);

                                                if ($result->num_rows > 0) {
                                                    while ($row = $result->fetch_assoc()) {


                                            ?>

                                                        <tr>
                                                            <td><?php echo $row['month'];  ?></td>
                                                            <td><?php echo $row['avg_tem'] . "&nbsp; °C"; ?></td>
                                                            <td><?php echo $row['avg_hum'] . "&nbsp;&nbsp; g/c³"; ?></td>
                                                            <td><?php echo $row['avg_mos'] . "&nbsp; m³"; ?></td>
                                                        </tr>
                                            <?php

                                                    }
                                                }
                                                $conn = null;
                                            }
                                            ?>


                                        </tbody>

                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- state end-->
                </div>

            </main>
            <!--main contents end-->
        </div>

        <!-- Content_right_End -->
        <!-- Footer -->
        <?php include_once('footer.php') ?>

        <!-- Footer_End -->
    </div>
    <script type="text/javascript" src="assets/js/jquery.min.js"></script>
    <script type="text/javascript" src="assets/js/popper.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!--datatables-->
    <script src="assets/js/jquery.dataTables.min.js"></script>
    <script src="assets/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/custom.js" type="text/javascript"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#bs4-table').DataTable({
                "order": [
                    [0, "desc"]
                ]
            });
        });
    </script>

</body>

</html>