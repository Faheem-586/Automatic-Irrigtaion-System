<?php
session_start(); 
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <?php include_once('links.php') ?>

    <title>Automatic Irrigation System</title>

</head>

<body class="bg_darck">

    <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="Page_title">
                    Automatic Irrigation System
                </div>
                <br>
                <div class="login-form">
                    <form role="form" method="POST">

                        <div class="form-group">
                            <label>User Name</label>
                            <input type="text" name="USERNAME" class="form-control" placeholder="User Name" required>
                        </div>

                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" name="EMAIL" class="form-control" placeholder="Email Address" required>
                        </div>

                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" name="PASSWORD" class="form-control" placeholder="Password" required>
                        </div>

                        <button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30">Register</button>
                        <br>
                        <br>

                        <?php 

                        if (isset($_POST["USERNAME"])) {

                            include_once("DBConnection.php");
                            date_default_timezone_set("Asia/Karachi");
                            $conn = new DBCon();

                            $conn->open();
                            $usrname = $_POST['USERNAME'];
                            $email = $_POST['EMAIL'];
                            $pswrd = $_POST['PASSWORD'];

                            //   echo $usrname;
                            $sql = null;

                            $sql = "INSERT INTO users (userid, name, password) VALUES ('$email', '$usrname','$pswrd')";
                            //    echo $sql;
                            if ($conn->db->query($sql) ==  TRUE) {
                                echo "  
                                    <span class='pull-left'><h6 class='Success_msg'> ✓ Thank You...! </h6></span>
                                    <span class='pull-right'><h6 class='Success_msg'><a href='login.php'>Now Login here..!</a></h6></span>
                                <br><br>";
                            } else {
                                echo "<h5 class='Error_msg'> ✖ Already have an account on this email...!</h5>";
                            }
                            $conn->db->close();
                        }


                        ?>

                        <php echo $error_str ?>
                            <br>
                            <div class="register-link m-t-15 text-center">
                                <p>Already have account ?
                                    <a href="login.php"> Sign In </a>
                                </p>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php include_once('scripts.php') ?>

</body>

</html>