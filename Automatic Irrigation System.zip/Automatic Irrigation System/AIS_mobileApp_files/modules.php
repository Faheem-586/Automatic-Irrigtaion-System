<?php
session_start();

if (!isset($_SESSION["login_email"])) {
    header("location: signup.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <?php include_once('links.php') ?>

    <title>Automatic Irrigation System</title>

</head>

<body>
    <div id="loader_wrpper">
        <div class="loader_style"></div>
    </div>

    <div class="wrapper">
        <?php include_once('header.php') ?>


        <!-- Content_right -->
        <div class="container_full">

            <?php include_once('menu.php') ?>

            <div class="content_wrapper">
                <div class="container-fluid">
                    <!-- breadcrumb -->
                    <div>
                        <br>
                    </div>
                    <!-- Section -->
                    <section class="chart_section">

                        <?php
                        include_once("DBConnection.php");
                        date_default_timezone_set("Asia/Karachi");
                        $conn = new DBCon();

                        if ($conn->Open()) {

                            $sql = "SELECT * FROM irrigation_processes order by irrigation_ID desc limit 1";
                            $result = $conn->db->query($sql);
                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();
                                $end_time = $row['end_time'];
                                if ($end_time == NULL) {
                                    $valve_status = 'ON';
                                } else {
                                    $valve_status = 'OFF';
                                }
                            }

                        ?>
                            <div class="row">
                                <div class="col-12">
                                    <div style="background-color:#96CAEF" class="info_items d-flex align-items-center">

                                        <div class="info_item_content">
                                            <span class="card-text-sm">Current<br>
                                                <span class="card-text">Valve Status</span>
                                            </span>
                                        </div>

                                        <div class="info_item_content">
                                            <span class="card-text-big"> <?php echo $valve_status; ?> &nbsp; </span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php


                            $conn = null;
                        }
                        ?>

                        <?php
                        include_once("DBConnection.php");
                        date_default_timezone_set("Asia/Karachi");
                        $conn = new DBCon();

                        if ($conn->Open()) {
                            $sql = "SELECT * FROM sensor_values ORDER BY date_and_time DESC";
                            $result = $conn->db->query($sql);

                            if ($result->num_rows > 0) {
                                $row = $result->fetch_assoc();

                                //FOR AIS TIMW
                                $newDate = new DateTime($row['date_and_time']);
                                $date = $newDate->format('j, m, Y');
                                $time = $newDate->format('H');

                                //FOR CURRENT TIME
                                date_default_timezone_set('Asia/Karachi');
                                $newDate = new DateTime(date('m/d/Y h:i:s a', time()));
                                $current_date = $newDate->format('j, m, Y');
                                $current_time = $newDate->format('H');

                                //  echo $date . "<br>";
                                //  echo $time . "<br>";

                                //  echo $current_date . "<br>";
                                // echo $current_time . "<br>";

                                $module_status = "Disconnected";
                                $mark = "❌";

                                if ($date == $current_date) {
                                    if ($time == $current_time) {
                                        $module_status = "Connected";
                                        $mark = "✔️";
                                    }
                                }


                        ?>

                                <div class="row">
                                    <div class="col-12">
                                        <div style="background-color:#96CAEF" class="info_items d-flex align-items-center">

                                            <div class="info_item_content">
                                                <span class="card-text-sm">Gateway Module<br>
                                                    <span class="card-text"><?php echo $module_status ?></span>
                                                </span>
                                            </div>

                                            <div class="info_item_content">
                                                <span class="card-text-big"><?php echo $mark ?><small class="card-text-unit"></small>&nbsp;</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-12">
                                        <div style="background-color:#96CAEF" class="info_items  d-flex align-items-center">

                                            <div class="info_item_content">
                                                <span class="card-text-sm">Control Module<br>
                                                    <span class="card-text"><?php echo $module_status ?></span>
                                                </span>
                                            </div>

                                            <div class="info_item_content">
                                                <span class="card-text-big"><?php echo $mark ?><small class="card-text-unit"></small>&nbsp;</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-12">
                                        <div style="background-color:#96CAEF" class="info_items d-flex align-items-center">

                                            <div class="info_item_content">
                                                <span class="card-text-sm">Sensor module<br>
                                                    <span class="card-text"><?php echo $module_status ?></span>
                                                </span>
                                            </div>

                                            <div class="info_item_content">
                                                <span class="card-text-big"><?php echo $mark ?><small class="card-text-unit"></small>&nbsp;</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-6">
                                        <a href="table_SN.php" class="btn btn-outline-dark btn-lg  btn-block"> <b>Show <br> Sensor<br> Readings</b></a>
                                    </div>

                                    <div class="col-6">
                                        <a href="table_IR.php" class="btn btn-outline-dark btn-lg  btn-block"><b> Show <br> Irrigation<br> Records</b></a>
                                    </div>
                                </div>

                                <br>
                        <?php

                            }
                            $conn = null;
                        }
                        ?>
                    </section>
                    <!-- Section_End -->

                </div>
            </div>
        </div>
        <!-- Content_right_End -->
        <!-- Footer -->
        <?php include_once('footer.php') ?>
        <!-- Footer_End -->
    </div>

    <?php include_once('scripts.php') ?>

</body>

</html>